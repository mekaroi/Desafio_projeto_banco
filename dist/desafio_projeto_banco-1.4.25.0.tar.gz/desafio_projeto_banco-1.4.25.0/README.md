## Meu Banco

Um pacote Python simples que simula um sistema bancário com funcionalidades basicas de criação de contas e operações.

## Description

- Criar contas bancárias com tilular, funções de depósito, saque e extrato.
- Armazenamento de multiplas contas.
- Listar todas as contas cadastradas com seus respectivos usuarios.

## Installation

Você pode instalar o pacote Desafio_projeto_banco_V1 usando o pip:

pip install Desafio_projeto_banco_V1

## Acuthor

Igor Merkaro

## License

[MIT](https://choosealicense.com/licenses/mit/)